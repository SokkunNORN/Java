package org.pnc.wep2019.finalExam;

public interface iMembership {
	double getDiscount();
}
