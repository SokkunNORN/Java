package sokkunNorn_CH5_HW1;

public class Book {

	private String title;
	private String author;
	private int publishYear;
	private boolean isBorrowed;
	
	public Book(String title, String author, int publishYear) {
		this.title = title;
		this.author = author;
		this.publishYear = publishYear;
	}
	
	public String borrow() {
		return "Available to borrow";
	}
	
	public String returnBack() {
		return "No Available to borrow";
	}
	
	String getTitle() {
		return this.title;	
	}
	
	String getAuthor() {
		return this.author;
	}
	
	int getPublishYear() {
		return publishYear;		
	}
	
	Boolean getBorrowed() {
		if (isBorrowed == false) {
			System.out.println("Available to borrow");
		} else {
			System.out.println("No Available to borrow");
		}
		return isBorrowed;
		
	}

	@Override
	public String toString() {
		return "Title: " + title + "   \n by " + author + "--published " + publishYear + "   \n Status: " + returnBack();
	}
	
	
	
	
}
