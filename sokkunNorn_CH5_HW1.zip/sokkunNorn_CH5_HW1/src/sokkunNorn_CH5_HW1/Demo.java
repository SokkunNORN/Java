package sokkunNorn_CH5_HW1;

import java.util.ArrayList;
public class Demo {

	public static void main(String[] args) {

		
		Book book1 = new Book("Don't make me think", "Steve Krung", 2000);
		Book book2 = new Book("Pro java programming", "Terrill", 2005);
		Book book3 = new Book("Programming in python 3", "Mark Summerfield", 2005);
		Book book4 = new Book("The clean coder", "Robert", 2011);
		Book book5 = new Book("The art of Agile development", "James Shore", 2007);
		Book book6 = new Book("Head First Design Patterns", "Eric Freeman", 2004);
		Book book7 = new Book("The Linux Command Line", "Willian", 2009);
		Book book8 = new Book("Code Complete", "Steve", 1993);
		Book book9 = new Book("Unit Test Patterns", "Gerard Meszaros", 2003);
		Book book10 = new Book("The C++ Programming Language", "Bjarne Stroustup", 2013);
		
		ArrayList<Book> books = new ArrayList<Book>();
			books.add(book1);
			books.add(book2);
			books.add(book3);
			books.add(book4);
			books.add(book5);
			books.add(book6);
			books.add(book7);
			books.add(book8);
			books.add(book9);
			books.add(book10);

		for (int i = 0; i < books.size(); i++) {
			System.out.println(books.get(i));
		}		

	    // Print the list objects in tabular format.
		System.out.println();
		System.out.println("--------------------------------------------------------------------------------------------------------------");
	    System.out.printf("%28s %23s %20s %27s", "TITLE", "AUTHOR", "YEAR", "STATUS");
	    System.out.println();
	    System.out.println("--------------------------------------------------------------------------------------------------------------");
	    for(Book book: books){
	        System.out.format("%28s %23s %20s %27s",
	                book.getTitle(), book.getAuthor(), book.getPublishYear(), book.returnBack());
	        System.out.println();
	    }
	    System.out.println("--------------------------------------------------------------------------------------------------------------");
	    
		
	}

}
