
public interface ITaxPayer {
	double caculateTax(double salary);
}
